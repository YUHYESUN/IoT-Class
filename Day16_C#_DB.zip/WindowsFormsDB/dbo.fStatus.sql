﻿CREATE TABLE [dbo].[fStatus] (
    [fCode] NCHAR(10)  NOT NULL,
    [Temp]  NCHAR (5)  NULL,
    [Hum]   NCHAR (10) NULL
);

