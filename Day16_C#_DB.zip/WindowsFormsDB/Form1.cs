﻿
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsDB
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        
        private void menumig_Click(object sender, EventArgs e)
        {
            DialogResult ret = openFileDialog1.ShowDialog();

            if (ret == DialogResult.Cancel) return;

            string fname = openFileDialog1.FileName;

            StreamReader sr = new StreamReader(fname);

            

            string buf = sr.ReadLine();

            string[] rows = buf.Split(',');

            for (int i = 0; i < rows.Length; i++)
            {
                textBox1.Text += $" {rows[i]}";
                dataGridView1.Columns.Add("rname", $"{rows[i]}");

            }
            textBox1.Text += $"\r\n";


            while (true)
            {
                
                buf = sr.ReadLine();

                if (buf == null) break;

                rows = buf.Split(',');

                // int rldx=dataGridView1.Rows.Add();

                dataGridView1.Rows.Add(rows);               //이게 간단한 방법

                 for (int i = 0; i < rows.Length; i++)
                 {
                     textBox1.Text += $" {rows[i]}";
                    // dataGridView1.Rows[rldx].Cells[i].Value=$"{rows[i]}";

                 }
                    
                textBox1.Text += $"\r\n";
                

            }

            






        }

        string DBsqlcon= @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=[fname];Integrated Security=True;Connect Timeout=30";

        SqlConnection DBsql = new SqlConnection();

        SqlCommand Sqlcmd = new SqlCommand();


        private void menuOpenDB_Click(object sender, EventArgs e)
        {

            try
            {
                DialogResult DB = openFileDialog1.ShowDialog();

                if (DB == DialogResult.Cancel) return;

                string DBname = openFileDialog1.FileName;

               

                Sqlcmd.Connection = DBsql;

                //DBsql.ConnectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\KOSTA\Documents\testDB.mdf;Integrated Security=True;Connect Timeout=30";

                DBsqlcon = DBsqlcon.Replace("[fname]", DBname);

                DBsql.ConnectionString = DBsqlcon;

                DBsql.Open();

                sblabel1.Text = $"{openFileDialog1.SafeFileName} DB open success";

                sblabel1.BackColor = Color.GreenYellow;
            }
            catch(Exception er)
            {

                MessageBox.Show(er.Message);

                sblabel1.Text = $"DB open fail :( ";

                sblabel1.BackColor = Color.Red;

            }

            

        }

        private void MenuExeSql_Click(object sender, EventArgs e)
        {

            Runsql(textBox1.Text);

            //밑에 애들은 runsql로 묶음

           /* string sql = textBox1.Text;

            Sqlcmd.CommandText = sql;
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            Sqlcmd.ExecuteNonQuery(); */              //select 문 제외(update, insert, delete, create) - return 값이 없는 value를 수행해 줌 

 //           Sqlcmd.ExecuteReader();                 //select 문을 위한 그러한 함수~
 ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////         
 


        }

        private void MenuExSelSql_Click(object sender, EventArgs e)
        {

            Runsql(textBox1.SelectedText);
          
        }

        public static string getToken(int index, char deli, string str)
        {
            string[] Str = str.Split(deli);
            string ret = Str[index];
            return ret;

        }
        object str;

        string TableName;                       //다른 메뉴에서 사용할 DB Table 이름

        int Runsql(string sql)
        {
            try
            {

                Sqlcmd.CommandText = sql;
               

                if (getToken(0,' ', sql).ToUpper() == "SELECT")
                {

                    SqlDataReader sr=Sqlcmd.ExecuteReader();

                    TableName = getToken(3, ' ', sql);
                    
                    dataGridView1.Rows.Clear();

                    dataGridView1.Columns.Clear();

                    for (int i = 0; i<sr.FieldCount; i++)
                    {
                        object cname = sr.GetName(i);
                        dataGridView1.Columns.Add("cname", $"{cname}");

                    }


                    for (int i=0; sr.Read(); i++)                          //레코드 한줄씩 read
                    {
                       // string buf = "";

                        int rldx = dataGridView1.Rows.Add();

                        for (int j=0; j<sr.FieldCount; j++)
                        {

                             str= sr.GetValue(j);                   //한줄씩 확인

                            // buf += $"{str} ";

                            dataGridView1.Rows[rldx].Cells[j].Value = $"{str}";

                        }

                        // textBox1.Text += $"\r\n{buf}\r\n";
                        

                    }

                   
                    sr.Close();

                }
                else
                {

                    Sqlcmd.ExecuteNonQuery();

                }

                sblabel1.Text = $"Success ";

                sblabel1.BackColor = Color.ForestGreen;

            }
            catch(SqlException e1)
            {
                MessageBox.Show(e1.Message);

                sblabel1.Text = $"Error ";

                sblabel1.BackColor = Color.DarkRed;
            }
            catch(InvalidOperationException e2)
            {
                MessageBox.Show(e2.Message);

                sblabel1.Text = $"Error ";

                sblabel1.BackColor = Color.DarkRed;

            }

            return 0;
            
        }
        
        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {

            if (e.KeyCode == Keys.Enter)
            {

                string str = textBox1.Text;

                string[] arr = str.Split('\n');

                Runsql(arr[arr.Length - 1].Trim());

            }
        }
        string selcell;

        private void dataGridView1_CellBeginEdit(object sender, DataGridViewCellCancelEventArgs e)
        {
            int row = e.RowIndex;
            int col = e.ColumnIndex;
  //        string selcell = dataGridView1.Rows[row].Cells[col].Value.ToString();

            selcell = dataGridView1.Rows[row].Cells[col].ToolTipText=".";

  //        MessageBox.Show(selcell);
            

        }
        
        private void menuupdate_Click(object sender, EventArgs e)
        {
            for(int i=0; i<dataGridView1.Rows.Count; i++)
            {
                for(int j=0; j<dataGridView1.Columns.Count; j++)
                {
                    string s = dataGridView1.Rows[i].Cells[j].ToolTipText;

                    if (s == ".")
                    {
                        string tn = TableName;
                        string fn = dataGridView1.Columns[j].HeaderText;
                        string ct = (string)dataGridView1.Rows[i].Cells[j].Value;
                        string kn = dataGridView1.Columns[0].HeaderText;
                        string kt = (string)dataGridView1.Rows[i].Cells[0].Value;
                        string sql = $"update {tn} set {fn}={ct} where {kn}={kt}";

                        Runsql(sql);

                    }
                }
            }

            
        }
    }
}
