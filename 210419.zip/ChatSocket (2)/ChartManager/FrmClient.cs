﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using static myLib.LibSor;

namespace ChartManager
{
    public partial class FrmClient : Form
    {
        public FrmClient()
        {
            InitializeComponent();
        }

        delegate void cbAddText(string s);
        void AddText(string str)
        {
            if(tbReceive.InvokeRequired)
            {
                cbAddText cb = new cbAddText(AddText);
                object[] oArr = { str };
                Invoke(cb, oArr);  //Invoke(cb, new object[] {str});
            }
            else
                tbReceive.AppendText(str); //byte[]의 size만큼 변환 (null 포함)
        }

        private void splitContainer1_SplitterMoved(object sender, SplitterEventArgs e)
        {
            int size1 = 200; //splitContainer1.Panal2 의 사이즈 ->고정 원츄

            splitContainer1.SplitterDistance = splitContainer1.Size.Width - size1;
        }

        Thread threadClient = null;
        Socket sock = null;
        private void btnConnect_Click(object sender, EventArgs e)
        {
            try
            {
                if (sock == null)
                {
                    sock = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                }
                else
                {
                    if(threadClient != null)
                    {
                        threadClient.Abort();
                        threadClient = null;
                    }
                    sock.Close();
                    sock = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                }
                //sock.Connect(tbIP.Text, int.Parse(tbPort.Text)); //blocking mode : timeout 발생 전까지 (2-4초)
                Thread ConThread = new Thread(ConnectProcess);
                ConThread.Start();
                while(true)
                {
                    if (ConThread.IsAlive) break;
                }

                sbLabel1.Text = ((IPEndPoint)(sock.RemoteEndPoint)).Address.ToString(); //12.0.0.1:12345
                sbLabel2.Text = ((IPEndPoint)(sock.RemoteEndPoint)).Port.ToString();

                if (threadClient == null)
                {
                    threadClient = new Thread(ClientProcess);
                    threadClient.Start();
                }
            }
            catch (Exception e1)
            {
                tbReceive.AppendText(e1.Message + "\r\n");
            }
        }

        void ConnectProcess()
        {
            sock.Connect(tbIP.Text, int.Parse(tbPort.Text));
        }

        void ClientProcess() //Thread 등록 프로세스
        {
            while(true)
            {
                int n = sock.Available;
                if(n>0)
                {
                    byte[] bArr = new byte[n]; //c#에서의 통신은 byte[] ;c/c++ char
                    sock.Receive(bArr);
                    AddText(Encoding.Default.GetString(bArr));
                }
            } 
        }

        private void btnSend_Click(object sender, EventArgs e)
        {
            try
            {
                if (sock.Connected == true)
                {
                    string str = tbSend.Text.Trim();
                    string[] sArr = str.Split('\r'); //multiline \r\n
                    string sLast = sArr[sArr.Length - 1];

                    sock.Send(Encoding.Default.GetBytes(sLast));
                }
                else
                {
                    AddText("서버와의 통신이 원활하지 않습니다. \r\n");
                }
            }
            catch (Exception e1)
            {
                AddText(e1.Message);
            }
           
        }

        iniFile ini = new iniFile(".\\ChatClient.ini");
        private void FrmClient_Load(object sender, EventArgs e)
        {
            int x1, x2, y1, y2;
            tbIP.Text = ini.GetString("Server", "IP","127.0.0.1");
            tbPort.Text = ini.GetString("Server", "Port", "9012");
            x1 = int.Parse(ini.GetString("Form", "LocationX", "0"));
            y1 = int.Parse(ini.GetString("Form", "LocationY", "0"));
            this.Location = new Point(x1, y1);
            x2 = int.Parse(ini.GetString("Form", "SizeX", "500"));
            y2 = int.Parse(ini.GetString("Form", "SizeY", "500"));
            this.Size = new Size(x2, y2);

        }

        private void FrmClient_FormClosing(object sender, FormClosingEventArgs e)
        {
            ini.SetString("Server", "IP", tbIP.Text);
            ini.SetString("Server", "Port", tbPort.Text);

            ini.SetString("Form", "LocationX", $"{Location.X}");
            ini.SetString("Form", "LocationY", $"{Location.Y}");
            ini.SetString("Form", "SizeX", $"{Size.Width}");
            ini.SetString("Form", "SizeY", $"{Size.Height}");
        }
    }
}
