﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsGraph
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
       public int x , y , z ;
      
        

       

        public void button1_Click(object sender, EventArgs e)
        {
            

            x = int.Parse(textBox1.Text);
            y = int.Parse(textBox2.Text);
            z = int.Parse(textBox3.Text);




        }
    }
}
