﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsGraph
{
    public partial class Form1 : Form
    {
        Graphics GDC;


        public Form1()
        {
            InitializeComponent();

            GDC = pictureBox1.CreateGraphics();

        }

         public Form2 form2 = new Form2();


        

        private void MenuDraw_Click(object sender, EventArgs e)
        {
            form2.button1.Visible = true;

            form2.ShowDialog();


        }



        private void pictureBox1_Paint(object sender, PaintEventArgs e)
        {
            /*Pen pen = new Pen(Color.Red, 10);
            e.Graphics.DrawEllipse(pen, 100, 100, 200, 200);*/



        }


        Point fp;
        Boolean status;
        int draw;
        public Pen pen;
        
        private void pictureBox1_MouseDown(object sender, MouseEventArgs e)
        {
            pen = new Pen(colo, form2.z);
            Pen pen1 = new Pen(BackColor, 30);
            
            int x = e.X;
            int y = e.Y;
            

            if (e.Button == MouseButtons.Left )
            {
                status = true;
                fp = new Point(x, y);
                if (draw == 1){
                    
                    GDC.DrawEllipse(pen, x, y, form2.x, form2.y);
                }
                else if (draw == 10)
                {
                    GDC.DrawEllipse(pen1, x, y, 30, 30);

                }
                //GDC.DrawArc()

                // GDC.DrawEllipse(pen, x, y, form2.x, form2.y);

            }
            





        }

        private void pictureBox1_Resize(object sender, EventArgs e)
        {
            GDC = pictureBox1.CreateGraphics();
        }

        private void MenuEraser_Click(object sender, EventArgs e)
        {
            sbpanel2.Text = "전체 지우기";
            GDC.Clear(DefaultBackColor);


        }

        private void M_Click(object sender, EventArgs e)
        {
            form2.button1.Visible = false;
            form2.textBox1.Text = form2.x.ToString();
            form2.textBox2.Text = form2.y.ToString();
            form2.textBox2.Text = form2.z.ToString();

            form2.ShowDialog();



        }

        


        private void pictureBox1_MouseMove(object sender, MouseEventArgs e)
        {

            //Pen pen = new Pen(Color.Red, form2.z);
            Pen pen1 = new Pen(BackColor, 30);


            int x = e.X;
            int y = e.Y;

            sbpanel.Text = $"{x},{y}";
            if (status)
            {
                if (draw == 0)
                {

                    Point lp = new Point(x, y);
                    GDC.DrawLine(pen, fp, lp);
                    fp = lp;
                }
                else if (draw == 10)
                {

                    GDC.DrawEllipse(pen1, x, y, 30, 30);
                }
            }
            


           /* if (e.Button == MouseButtons.Left)
            {

                // GDC.DrawEllipse(pen, x, y, form2.x, form2.y);

            }
            else if (e.Button == MouseButtons.Middle)
            {
                GDC.DrawEllipse(pen1, x, y, 30, 30);
            }
*/
            

        }

        private void pictureBox1_MouseUp(object sender, MouseEventArgs e)
        {
            status = false;
        }

        private void menudrawpen_Click(object sender, EventArgs e)
        {
            sbpanel2.Text = "선그리기";
            sbPanel3.Text = $"{colo.Name},{form2.z}";
            draw = 0;

        }

        private void menuera_Click(object sender, EventArgs e)
        {
            sbpanel2.Text = "부분 지우기";
            draw = 10;
        }

        private void menudrawcir_Click(object sender, EventArgs e)
        {
            sbpanel2.Text = "원그리기";
            form2.button1.Visible = true;

            form2.ShowDialog();
            sbPanel3.Text = $"{colo.Name},{form2.z}";
            draw = 1;
        }
       public Color colo;
        public void color_Click(object sender, EventArgs e)
        {
            DialogResult CD = colorDialog1.ShowDialog();

            if (CD == DialogResult.Cancel) return;
            
            colo= colorDialog1.Color;

            sbPanel3.Text = $"{colo.Name},{form2.z}";

        }
    }
}

