﻿
namespace WindowsFormsGraph
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Menu = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.MenuDraw = new System.Windows.Forms.ToolStripMenuItem();
            this.menudrawpen = new System.Windows.Forms.ToolStripMenuItem();
            this.menudrawcir = new System.Windows.Forms.ToolStripMenuItem();
            this.menudrawarc = new System.Windows.Forms.ToolStripMenuItem();
            this.menudrawline = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuEraser = new System.Windows.Forms.ToolStripMenuItem();
            this.menuera = new System.Windows.Forms.ToolStripMenuItem();
            this.M = new System.Windows.Forms.ToolStripMenuItem();
            this.color = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.sbpanel = new System.Windows.Forms.ToolStripStatusLabel();
            this.sbpanel2 = new System.Windows.Forms.ToolStripStatusLabel();
            this.sbPanel3 = new System.Windows.Forms.ToolStripStatusLabel();
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.Menu.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox1.ContextMenuStrip = this.Menu;
            this.pictureBox1.Location = new System.Drawing.Point(0, 1);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(614, 459);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Paint += new System.Windows.Forms.PaintEventHandler(this.pictureBox1_Paint);
            this.pictureBox1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseDown);
            this.pictureBox1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseMove);
            this.pictureBox1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseUp);
            this.pictureBox1.Resize += new System.EventHandler(this.pictureBox1_Resize);
            // 
            // Menu
            // 
            this.Menu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MenuDraw,
            this.MenuEraser,
            this.M,
            this.color});
            this.Menu.Name = "Menu";
            this.Menu.Size = new System.Drawing.Size(181, 114);
            // 
            // MenuDraw
            // 
            this.MenuDraw.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menudrawpen,
            this.menudrawcir,
            this.menudrawarc,
            this.menudrawline});
            this.MenuDraw.Name = "MenuDraw";
            this.MenuDraw.Size = new System.Drawing.Size(138, 22);
            this.MenuDraw.Text = "그리기";
            this.MenuDraw.Click += new System.EventHandler(this.MenuDraw_Click);
            // 
            // menudrawpen
            // 
            this.menudrawpen.Name = "menudrawpen";
            this.menudrawpen.Size = new System.Drawing.Size(138, 22);
            this.menudrawpen.Text = "연필 그리기";
            this.menudrawpen.Click += new System.EventHandler(this.menudrawpen_Click);
            // 
            // menudrawcir
            // 
            this.menudrawcir.Name = "menudrawcir";
            this.menudrawcir.Size = new System.Drawing.Size(138, 22);
            this.menudrawcir.Text = "원 그리기";
            this.menudrawcir.Click += new System.EventHandler(this.menudrawcir_Click);
            // 
            // menudrawarc
            // 
            this.menudrawarc.Name = "menudrawarc";
            this.menudrawarc.Size = new System.Drawing.Size(138, 22);
            this.menudrawarc.Text = "호 그리기";
            // 
            // menudrawline
            // 
            this.menudrawline.Name = "menudrawline";
            this.menudrawline.Size = new System.Drawing.Size(138, 22);
            this.menudrawline.Text = "선 그리기";
            // 
            // MenuEraser
            // 
            this.MenuEraser.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuera});
            this.MenuEraser.Name = "MenuEraser";
            this.MenuEraser.Size = new System.Drawing.Size(138, 22);
            this.MenuEraser.Text = "모두 지우기";
            this.MenuEraser.Click += new System.EventHandler(this.MenuEraser_Click);
            // 
            // menuera
            // 
            this.menuera.Name = "menuera";
            this.menuera.Size = new System.Drawing.Size(138, 22);
            this.menuera.Text = "부분 지우기";
            this.menuera.Click += new System.EventHandler(this.menuera_Click);
            // 
            // M
            // 
            this.M.Name = "M";
            this.M.Size = new System.Drawing.Size(138, 22);
            this.M.Text = "보기";
            this.M.Click += new System.EventHandler(this.M_Click);
            // 
            // color
            // 
            this.color.Name = "color";
            this.color.Size = new System.Drawing.Size(180, 22);
            this.color.Text = "color";
            this.color.Click += new System.EventHandler(this.color_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sbpanel,
            this.sbpanel2,
            this.sbPanel3});
            this.statusStrip1.Location = new System.Drawing.Point(0, 463);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(614, 22);
            this.statusStrip1.TabIndex = 1;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // sbpanel
            // 
            this.sbpanel.Name = "sbpanel";
            this.sbpanel.Size = new System.Drawing.Size(31, 17);
            this.sbpanel.Text = "좌표";
            // 
            // sbpanel2
            // 
            this.sbpanel2.Name = "sbpanel2";
            this.sbpanel2.Size = new System.Drawing.Size(43, 17);
            this.sbpanel2.Text = "그리기";
            // 
            // sbPanel3
            // 
            this.sbPanel3.Name = "sbPanel3";
            this.sbPanel3.Size = new System.Drawing.Size(52, 17);
            this.sbPanel3.Text = "Pen info";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(614, 485);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Form1";
            this.Text = "그림판";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.Menu.ResumeLayout(false);
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel sbpanel;
        private System.Windows.Forms.ContextMenuStrip Menu;
        private System.Windows.Forms.ToolStripMenuItem MenuDraw;
        private System.Windows.Forms.ToolStripMenuItem MenuEraser;
        private System.Windows.Forms.ToolStripMenuItem M;
        private System.Windows.Forms.ToolStripStatusLabel sbpanel2;
        private System.Windows.Forms.ToolStripStatusLabel sbPanel3;
        private System.Windows.Forms.ToolStripMenuItem menudrawpen;
        private System.Windows.Forms.ToolStripMenuItem menudrawcir;
        private System.Windows.Forms.ToolStripMenuItem menudrawarc;
        private System.Windows.Forms.ToolStripMenuItem menudrawline;
        private System.Windows.Forms.ToolStripMenuItem menuera;
        private System.Windows.Forms.ColorDialog colorDialog1;
        public System.Windows.Forms.ToolStripMenuItem color;
    }
}

