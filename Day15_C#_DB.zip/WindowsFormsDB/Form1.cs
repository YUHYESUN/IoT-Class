﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsDB
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        
        private void menumig_Click(object sender, EventArgs e)
        {
            DialogResult ret = openFileDialog1.ShowDialog();

            if (ret == DialogResult.Cancel) return;

            string fname = openFileDialog1.FileName;

            StreamReader sr = new StreamReader(fname);

            

            string buf = sr.ReadLine();

            string[] rows = buf.Split(',');

            for (int i = 0; i < rows.Length; i++)
            {
                textBox1.Text += $" {rows[i]}";
                dataGridView1.Columns.Add("rname", $"{rows[i]}");

            }
            textBox1.Text += $"\r\n";


            while (true)
            {
                
                buf = sr.ReadLine();

                if (buf == null) break;

                rows = buf.Split(',');

                // int rldx=dataGridView1.Rows.Add();

                dataGridView1.Rows.Add(rows);               //이게 간단한 방법

                 for (int i = 0; i < rows.Length; i++)
                 {
                     textBox1.Text += $" {rows[i]}";
                    // dataGridView1.Rows[rldx].Cells[i].Value=$"{rows[i]}";

                 }
                    
                textBox1.Text += $"\r\n";
                

            }

            






        }

        string DBsqlcon= @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=[fname];Integrated Security=True;Connect Timeout=30";

        SqlConnection DBsql = new SqlConnection();

        SqlCommand Sqlcmd = new SqlCommand();


        private void menuOpenDB_Click(object sender, EventArgs e)
        {

            try
            {
                DialogResult DB = openFileDialog1.ShowDialog();

                if (DB == DialogResult.Cancel) return;

                string DBname = openFileDialog1.FileName;

               

                Sqlcmd.Connection = DBsql;

                //DBsql.ConnectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\KOSTA\Documents\testDB.mdf;Integrated Security=True;Connect Timeout=30";

                DBsqlcon = DBsqlcon.Replace("[fname]", DBname);

                DBsql.ConnectionString = DBsqlcon;

                DBsql.Open();

                sblabel1.Text = $"{openFileDialog1.SafeFileName} DB open success";

                sblabel1.BackColor = Color.GreenYellow;
            }
            catch(Exception er)
            {

                MessageBox.Show(er.Message);

                sblabel1.Text = $"DB open fail :( ";

                sblabel1.BackColor = Color.Red;

            }

        }

        private void MenuExeSql_Click(object sender, EventArgs e)
        {

            Runsql(textBox1.Text);

            string sql = textBox1.Text;

            Sqlcmd.CommandText = sql;
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            Sqlcmd.ExecuteNonQuery();               //select 문 제외(update, insert, delete, create) - return 값이 없는 value를 수행해 줌 

 //           Sqlcmd.ExecuteReader();                 //select 문을 위한 그러한 함수~
 ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////         
 


        }

        private void MenuExSelSql_Click(object sender, EventArgs e)
        {

            Runsql(textBox1.SelectedText);
          
        }

        int Runsql(string sql)
        {
            try
            {

                Sqlcmd.CommandText = sql;
                Sqlcmd.ExecuteNonQuery();

            }
            catch(SqlException e1)
            {
                MessageBox.Show(e1.Message);
            }
            catch(InvalidOperationException e2)
            {
                MessageBox.Show(e2.Message);

            }

            return 0;
            
        }
    }
}
