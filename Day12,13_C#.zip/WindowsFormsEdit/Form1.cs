﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using mylibrary;

namespace WindowsFormsEdit
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            
        }

        private void 파일ToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void FileSave_Click(object sender, EventArgs e)
        {
            DialogResult ret1 = saveFileDialog1.ShowDialog();
            if (ret1 == DialogResult.OK)
            {
                string fname1 = saveFileDialog1.FileName;
                StreamWriter sw = new StreamWriter(fname1);
                string buf1 = textBox1.Text;
                sw.Write(buf1);
                sw.Close();
               
            }

            }

        private void FileOpen_Clicked(object sender, EventArgs e)
        {
            

          DialogResult ret= openFileDialog1.ShowDialog();                   //C++ DoMal과 같은 기능 
            if (ret == DialogResult.OK)
            {
                string fname = openFileDialog1.FileName;
                StreamReader sr = new StreamReader(fname);

                string buf=sr.ReadToEnd();
                textBox1.Text = buf;


                sr.Close();


                string filename = Path.GetFileName(fname);
               /* string[] filename = fname.Split('\\');

                int n = filename.Length;

                string fn = filename[n - 1];
*/



                //this.Text =this.Text+" ["+ filename+"]";
                this.Text += $"{    filename}";

                ////////////////////////////////////////////////////////////////////////////////////////////////////

                //위에 주석 코드와 같은 의미 
                /*
                                int n = Mylib.Count('\\', fname);
                                string fn = Mylib.getToken(n, '\\', fname);
                                this.Text += $"{    fn}";*/

                Form1_Load(sender,e);






            }


        }
       /* int Count(char deli, string str)            //str문자열의 deli 구분자 개수 
        {
            string[] Str = str.Split(deli);
            int n = Str.Length;
            return n-1;

        }
        string getToken(int index, char deli, string str)       
        {
            string[] Str = str.Split(deli);
            string ret = Str[index];
            return ret;

        }*/
        //              1. file open 후 Memo 창에 표시한 경우 -확인(o) 수정(x)
        //              2. New 메뉴 선택 후 문서 편집 - file 명 없음
        //              3. 기존 문서 중 일부 수정 - open file 명 있음
        int txtch = 0;

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (true) txtch = 1;
            
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (txtch == 1)
            {
                
            }
        }

        private void ViewFont_Click(object sender, EventArgs e)
        {
            DialogResult ret= fontDialog1.ShowDialog();
            if (ret == DialogResult.Cancel) return;

            Font f = fontDialog1.Font;

            textBox1.Font=f;
            Form1_Load(sender, e);

        }

        private void Form1_Load(object sender, EventArgs e)
            
        {
            SBlabel1.Text = textBox1.Font.Name;
            SBlabel2.Text = textBox1.Font.Size.ToString();
            SBlabel3.Text = textBox1.ForeColor.Name;

        }

        private void ViewColor_Click(object sender, EventArgs e)
        {
            DialogResult ret = colorDialog1.ShowDialog();
            if (ret == DialogResult.Cancel) return;

            Color color = colorDialog1.Color;

            textBox1.ForeColor=color;

            Form1_Load(sender, e);





        }
    }
}
