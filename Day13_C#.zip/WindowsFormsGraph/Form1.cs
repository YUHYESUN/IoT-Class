﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsGraph
{
    public partial class Form1: Form
    {
        Graphics GDC;

        
        public Form1()
        {
            InitializeComponent();

            GDC =pictureBox1.CreateGraphics();

        }
        
        public Form2 form2 = new Form2();
        public Boolean mouse = false;
        private void MenuDraw_Click(object sender, EventArgs e)
        {
            form2.button1.Visible = true;

            form2.ShowDialog();
          

        }

      

        private void pictureBox1_Paint(object sender, PaintEventArgs e)
        {
            /*Pen pen = new Pen(Color.Red, 10);
            e.Graphics.DrawEllipse(pen, 100, 100, 200, 200);*/



        }
        
        
        private void pictureBox1_MouseDown(object sender, MouseEventArgs e)
        {
            Pen pen = new Pen(Color.Red, form2.z);
            Pen pen1 = new Pen(BackColor, 30);
            mouse = true;
            int x = e.X;
            int y = e.Y;
            if (e.Button == MouseButtons.Left&&mouse==true)
            {
              
              
                GDC.DrawEllipse(pen, x, y, form2.x, form2.y);

            }
            else if (e.Button == MouseButtons.Middle&& mouse == true)
            {
                GDC.DrawEllipse(pen1, x, y, 30, 30);
            }
           




        }

        private void pictureBox1_Resize(object sender, EventArgs e)
        {
            GDC = pictureBox1.CreateGraphics();
        }

        private void MenuEraser_Click(object sender, EventArgs e)
        {
            GDC.Clear(DefaultBackColor);
           

        }

        private void M_Click(object sender, EventArgs e)
        {
            form2.button1.Visible = false;
            form2.textBox1.Text = form2.x.ToString();
            form2.textBox2.Text = form2.y.ToString();
            form2.textBox2.Text = form2.z.ToString();

            form2.ShowDialog();



        }

        private void pictureBox1_MouseUp(object sender, MouseEventArgs e)
        {
            mouse = false;
        }
    }
}
